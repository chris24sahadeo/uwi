with open('queries.txt') as queries:
  for query in queries:
    [query_type, timestamp_1, timestamp_2] = query
    print(f'{query_type} {timestamp_1}')